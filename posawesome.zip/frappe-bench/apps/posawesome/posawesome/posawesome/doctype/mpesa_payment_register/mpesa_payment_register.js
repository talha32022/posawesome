// Copyright (c) 2021, Youssef Restom and contributors
// For license information, please see license.txt

frappe.ui.form.on('Mpesa Payment Register', {
	// refresh: function(frm) {

	// }
});
