# -*- coding: utf-8 -*-
# Copyright (c) 2021, Youssef Restom and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestPOSOffer(unittest.TestCase):
	pass
